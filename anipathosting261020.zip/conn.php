<?php
// $conn=mysqli_connect("localhost", "root", "", "db_anipat");
$conn=mysqli_connect("localhost", "id15114464_proyek2py2020", "BuLaras.2020", "id15114464_db_anipat");
?>